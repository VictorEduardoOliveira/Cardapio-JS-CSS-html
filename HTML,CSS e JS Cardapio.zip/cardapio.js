let aux_1 = 0
let aux_2 = 0
let aux_3 = 0

let valor = parseFloat(0);
function pedir(num){
    if(num == 1){
        aux_1++
        document.getElementById("pedido-1").textContent = `Big Mac    ${aux_1}xUn    R$ ${aux_1*24.00}`
        valor += 24.00 
    } else if(num == 2){
        aux_2++
        document.getElementById("pedido-2").textContent = `Duplo Quarterão    ${aux_2}xUn    R$ ${aux_2*34.00}`
        valor += 34.00
    } else{
        aux_3++
        document.getElementById("pedido-3").textContent = `Tasty Turbo 3 Carnes    ${aux_3}xUn    R$ ${(aux_3*43.90).toFixed(2)}`
        valor += 43.90
    }
    console.log(valor.toFixed(2))
    document.getElementById("subtotal").textContent = `R$ ${valor.toFixed(2)}`
    document.getElementById("frete").textContent = "Frete: R$ 5.00"
    document.getElementById("total").textContent = `R$ ${(valor+5.00).toFixed(2)}`
}
